# NickysFixer
Fixes some Minecraft Server exploits and lag exploits

This plugin is not designed to be your Minecraft servers only exploit fixer, this Minecraft plugin is mainly for exploits that aren't often fixed by common ExploitFixers

Please run this plugin on spigot or paper or tunity or another fork (except craftbukkit/bukkit). This plugin is designed for 1.12.2 and other versions will most likely have issues.
